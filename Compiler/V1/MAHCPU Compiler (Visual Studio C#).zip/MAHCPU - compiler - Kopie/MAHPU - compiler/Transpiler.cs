﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MAHPU___compiler
{
    class Transpiler
    {
        static List<string> PRG;
        static List<string> PRG_2;
        public Transpiler(List<string> x)
        {
            PRG = x;
        }
        public void Main()
        {
            int j_count = 0;
            PRG_2 = new List<string>();
            for (int i = 0; i < PRG.Count; i++)
            {
                string cmd = PRG[i].Split(' ')[0];
                //Console.WriteLine($"{PRG[i]} | {PRG[i].IndexOf(' ')} | {PRG[i].Length - PRG[i].IndexOf(' ')}");
                string[] cmd_args = PRG[i].Substring(PRG[i].IndexOf(' ') + 1, PRG[i].Length - PRG[i].IndexOf(' ') - 1).Split(' ');

                switch (cmd)
                {
                    case "":

                        break;

                    case "draw_img":
                        {
                            Bitmap bm = new Bitmap(cmd_args[0]);

                            
                            int pos = 0;
                            for (int y = 0; y < 100; y++)
                            {
                                for (int x = 0; x < 100; x++)
                                {
                                    Color temp = bm.GetPixel(x, y);
                                    PRG_2.Add($"set_pixel {pos} {temp.R} {temp.G} {temp.B}");
                                    pos += 3;
                                }
                            }
                        }
                        PRG_2.Add($"print_scr");
                        break;



                    case "input":
                        /*
                        :read_1
                        inp temp
                        m_rem_var temp $x

                        if_jump read_1_done temp
                        jump read_1
                        :read_1_done
                        */
                        PRG_2.Add($"inp {cmd_args[0]}");
                        PRG_2.Add($"new_var SYS_input_temp");
                        PRG_2.Add($":SYS_input_JUMP_LOOP_{j_count}");
                        PRG_2.Add($"inp SYS_input_temp");
                        PRG_2.Add($"m_rem_var SYS_input_temp ${cmd_args[0]}");
                        PRG_2.Add($"if_jump SYS_input_JUMP_DONE_{j_count} SYS_input_temp");
                        PRG_2.Add($"jump SYS_input_JUMP_LOOP_{j_count}");
                        PRG_2.Add($":SYS_input_JUMP_DONE_{j_count}");

                        j_count++;

                        break;



                    default:
                        PRG_2.Add(PRG[i]);
                        break;
                }

            }

        }

        public List<string> Transpile()
        {
            Main();
            return PRG_2;
        }
    }
}
