﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Win32;
using System.Windows.Forms;

namespace MAHPU___compiler
{
    class Compiler
    {



        static List<(string name, int val)> VARS;
        static List<(string name, int val)> JUMPS;
        static int instr;
        static List<string> PRG;
        public Compiler(List<string> x)
        {
            PRG = x;
        }


        [STAThread]
        public void Main()
        {
            //List<string> PRG = ReadFile();
            instr = 0;
            VARS = new List<(string name, int val)>();
            JUMPS = new List<(string name, int val)>();



            List<string> PRG_DONE = new List<string>();

            List<(string cmd_, string jump_addr, int line)> JUMPS_TO_ADD = new List<(string cmd_, string jump_addr, int line)>();


            //PRG_DONE.Add();

            for (int i = 0; i < PRG.Count; i++)
            {
                string cmd = PRG[i].Split(' ')[0];
                //Console.WriteLine($"{PRG[i]} | {PRG[i].IndexOf(' ')} | {PRG[i].Length - PRG[i].IndexOf(' ')}");
                string[] cmd_args = PRG[i].Substring(PRG[i].IndexOf(' ') + 1, PRG[i].Length - PRG[i].IndexOf(' ') - 1).Split(' ');

                if (cmd.Length != 0)
                {
                    /*
                    if (cmd[0] == ':')
                    {
                        JUMPS.Add((cmd.Substring(1, cmd.Length - 1), instr));
                    }
                    */
                    if (cmd == "new_var")
                    {
                        bool te = true;
                        foreach ((string name, int x)X in VARS)
                        {
                            if (X.name == cmd_args[0])
                            {
                                te = false;
                            }
                        }
                        if (te)
                        {

                            VARS.Add((cmd_args[0], 0));
                        }
                    }
                }
            }



            for (int i = 0; i < PRG.Count; i++)
            {
                string cmd = PRG[i].Split(' ')[0];
                //Console.WriteLine($"{PRG[i]} | {PRG[i].IndexOf(' ')} | {PRG[i].Length - PRG[i].IndexOf(' ')}");
                string[] cmd_args = PRG[i].Substring(PRG[i].IndexOf(' ') + 1, PRG[i].Length - PRG[i].IndexOf(' ') - 1).Split(' ');

                /*
                Console.Write($"- {cmd}");
                foreach (string x in cmd_args)
                {
                    Console.Write($" | {x}");
                }
                Console.WriteLine();
                */
                if (cmd.Length != 0)
                {
                    if (cmd[0] == ':')
                    {
                        PRG_DONE.Add("0000 "); instr++;
                        Console.WriteLine($"NEW JUMP {cmd.Substring(1, cmd.Length - 1)} at {instr} ({PRG_DONE.Count})");
                        JUMPS.Add((cmd.Substring(1, cmd.Length - 1), instr - 2));
                    }

                }


                switch (cmd)
                {
                    case "":
                        break;



                    case "inp":
                        Console.WriteLine($"Reading input into {cmd_args[0]}");
                        PRG_DONE.Add($"1110{Get_BIN_Varadress(cmd_args[0])}"); instr++;
                        break;

                    case "debug_prnt":
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"1111{Get_BIN(4)}"); instr++;
                        }
                        break;


                    case "print_scr":
                        PRG_DONE.Add("1101");
                        instr++;
                        break;


                    case "if_jump":
                        Console.WriteLine($"IF Jumping to {cmd_args[0]}({Get_JUMP_NUM(cmd_args[0])}) if {cmd_args[1]} != 0| {Get_BIN(Get_JUMP_NUM(cmd_args[0]))}");
                        JUMPS_TO_ADD.Add(($"0001{Get_BIN(4)}", cmd_args[0], PRG_DONE.Count));
                        PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(Get_JUMP_NUM(cmd_args[0]))}"); instr++;
                        PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(4)}"); instr++;
                        //set var 0 to adress

                        PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN_Varadress(cmd_args[1])}"); instr++;
                        PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(0)}"); instr++;
                        //set REG 7 to Address of var and REG 8 to Adress

                        PRG_DONE.Add("1100"); instr++;
                        //make jump


                        break;



                    case "jump":
                        Console.WriteLine($"Jumping to {cmd_args[0]} ({Get_JUMP_NUM(cmd_args[0])}) | {Get_BIN(Get_JUMP_NUM(cmd_args[0]))}");

                        JUMPS_TO_ADD.Add(($"0001{Get_BIN(4)}", cmd_args[0], PRG_DONE.Count));

                        PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(Get_JUMP_NUM(cmd_args[0]))}"); instr++;
                        PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(4)}"); instr++;
                        //set var 0 to adress
                        PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(1)}"); instr++;
                        PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(4)}"); instr++;
                        //set var 1 to 1
                        PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(1)}"); instr++;
                        PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(0)}"); instr++;
                        //set REG 7 to 1 and REG 8 to Adress

                        PRG_DONE.Add("1100"); instr++;
                        //make jump
                        break;

                    case "new_var":
                        //VARS.Add((cmd_args[0],0));

                        PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(0)}"); instr++;
                        PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(4)}"); instr++;
                        break;

                    case "set_var":
                        if (cmd_args[1][0] == '$')
                        {
                            string addr = Get_BIN_Varadress(cmd_args[1].Substring(1, cmd_args[1].Length - 1));
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(4)}"); instr++;
                            // set var to REG 4
                        }
                        else
                        {
                            PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(int.Parse(cmd_args[1]))}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(4)}"); instr++;
                        }
                        break;

                    case "m_add_var":
                        if (cmd_args[1][0] == '$')
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            addr = Get_BIN_Varadress(cmd_args[1].Substring(1, cmd_args[1].Length - 1));
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("0111"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(1)}"); instr++;
                            // set Var to REG 1
                        }
                        else
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(int.Parse(cmd_args[1]))}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("0111"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(1)}"); instr++;
                            // set Var to REG 1
                        }
                        break;



                    case "m_and_var":
                        if (cmd_args[1][0] == '$')
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            addr = Get_BIN_Varadress(cmd_args[1].Substring(1, cmd_args[1].Length - 1));
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("1001"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(2)}"); instr++;
                            // set Var to REG 1
                        }
                        else
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(int.Parse(cmd_args[1]))}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("1001"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(2)}"); instr++;
                            // set Var to REG 1
                        }
                        break;



                    case "m_or_var":
                        if (cmd_args[1][0] == '$')
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            addr = Get_BIN_Varadress(cmd_args[1].Substring(1, cmd_args[1].Length - 1));
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("1010"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(2)}"); instr++;
                            // set Var to REG 1
                        }
                        else
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(int.Parse(cmd_args[1]))}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("1010"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(2)}"); instr++;
                            // set Var to REG 1
                        }
                        break;



                    case "m_not_var":
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4

                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add("1011"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(2)}"); instr++;
                            // set Var to REG 1
                        }
                        break;





                    case "m_rem_var":
                        if (cmd_args[1][0] == '$')
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            addr = Get_BIN_Varadress(cmd_args[1].Substring(1, cmd_args[1].Length - 1));
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("1000"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(1)}"); instr++;
                            // set Var to REG 1
                        }
                        else
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0]);
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4



                            PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(int.Parse(cmd_args[1]))}");
                            PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                            //set var 11 to REG 4 (Value to add)


                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                            PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                            //set REG 8 to var 11
                            PRG_DONE.Add("1000"); instr++;
                            //Add vars 10 and 11

                            PRG_DONE.Add($"0011{Get_BIN_Varadress(cmd_args[0])}{Get_BIN(1)}"); instr++;
                            // set Var to REG 1
                        }
                        break;



                    case "set_vram":
                        PRG_DONE.Add(SET_VRAM_SINGLE_VAL(cmd_args[0], cmd_args[1])); instr++;
                        break;

                    case "set_pixel":

                        if (cmd_args[0][0] == '$')
                        {
                            string addr = Get_BIN_Varadress(cmd_args[0].Substring(1, cmd_args[0].Length - 1));
                            PRG_DONE.Add($"0001{Get_BIN(5)}{Get_BIN(4)}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                            // Set var 0 to Register 4
                            PRG_DONE.Add($"0001{Get_BIN(5)}{addr}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                            // Set var 1 to var adress

                            PRG_DONE.Add($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                            // Set REG 4 to var adress

                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            // set var 10 to REG 4

                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                        }
                        else
                        {
                            PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(int.Parse(cmd_args[0]))}"); instr++;
                            PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(4)}"); instr++;
                            //set var 10 to index

                            PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                            //set REG 7 to var 10
                        }
                        PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(1)}"); instr++;
                        PRG_DONE.Add($"0011{Get_BIN(11)}{Get_BIN(4)}"); instr++;
                        //set var 11 to 1
                        PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                        //set REG 8 to var 11


                        /*
                        write.WriteLine("0111");
                        //Add vars 10 and 11
                        write.WriteLine($"0011{Get_BIN(10)}{Get_BIN(1)}");
                        //set var 10 to REG 1
                        */



                        PRG_DONE.Add(SET_VRAM_SINGLE_VAL_2($"${Get_BIN(10)}", cmd_args[1])); //instr++;

                        PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                        //set REG 7 to var 10
                        PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                        //set REG 8 to var 11
                        PRG_DONE.Add("0111"); instr++;
                        //Add vars 10 and 11
                        PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(1)}"); instr++;
                        //set var 10 to REG 1

                        PRG_DONE.Add(SET_VRAM_SINGLE_VAL_2($"${Get_BIN(10)}", cmd_args[2]));

                        PRG_DONE.Add($"0001{Get_BIN(7)}{Get_BIN(10)}"); instr++;
                        //set REG 7 to var 10
                        PRG_DONE.Add($"0001{Get_BIN(8)}{Get_BIN(11)}"); instr++;
                        //set REG 8 to var 11
                        PRG_DONE.Add("0111"); instr++;
                        //Add vars 10 and 11
                        PRG_DONE.Add($"0011{Get_BIN(10)}{Get_BIN(1)}"); instr++;
                        //set var 10 to REG 1

                        PRG_DONE.Add(SET_VRAM_SINGLE_VAL_2($"${Get_BIN(10)}", cmd_args[3]));
                        break;


                    default:

                        break;
                }
            }



            /*
            JUMPS_TO_ADD.Add(($"0001{Get_BIN(4)}", cmd_args[0], PRG.Count));

            PRG_DONE.Add($"0001{Get_BIN(4)}{Get_BIN(Get_JUMP_NUM(cmd_args[0]))}"); instr++;
            */

            foreach ((string cmd_, string jump_addr, int line) X in JUMPS_TO_ADD)
            {
                Console.WriteLine($"EDIT LINE {X.line} to jump to line({Get_JUMP_NUM(X.jump_addr)}) {X.jump_addr} | {X.cmd_}{Get_BIN(Get_JUMP_NUM(X.jump_addr))}");
                PRG_DONE[X.line] = $"{X.cmd_}{Get_BIN(Get_JUMP_NUM(X.jump_addr))}";
            }


            StreamWriter write = new StreamWriter("PRG_OUT.txt");

            foreach (string X in PRG_DONE)
            {
                write.WriteLine(X);
            }

            write.Close();




            Console.WriteLine("Done.");
            Console.ReadLine();
        }

        static string SET_VRAM_SINGLE_VAL_2(string ind, string val)
        {
            StringBuilder stringus = new StringBuilder();

            if (ind[0] == '$')
            {
                string addr = ind.Substring(1, ind.Length - 1);
                stringus.AppendLine($"0001{Get_BIN(5)}{Get_BIN(7)}"); instr++;
                stringus.AppendLine($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                // Set var 0 to Register 7
                stringus.AppendLine($"0001{Get_BIN(5)}{addr}"); instr++;
                stringus.AppendLine($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                // Set var 1 to var adress
                stringus.AppendLine($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                // Set REG 7 to var adress
            }
            else
            {
                stringus.AppendLine($"0001{Get_BIN(7)}{Get_BIN(int.Parse(ind))}"); instr++;
            }

            if (val[0] == '$')
            {
                string addr = Get_BIN_Varadress(val.Substring(1, val.Length - 1));
                stringus.AppendLine($"0001{Get_BIN(8)}{addr}"); instr++;
            }
            else
            {
                stringus.AppendLine($"0001{Get_BIN(5)}{Get_BIN(int.Parse(val))}"); instr++;
                stringus.AppendLine($"0011{Get_BIN(3)}{Get_BIN(5)}"); instr++;
                stringus.AppendLine($"0001{Get_BIN(8)}{Get_BIN(3)}"); instr++;
            }
            stringus.Append("0101"); instr++;

            return stringus.ToString();
        }

        static string SET_VRAM_SINGLE_VAL(string ind, string val)
        {
            StringBuilder stringus = new StringBuilder();

            if (ind[0] == '$')
            {
                string addr = Get_BIN_Varadress(ind.Substring(1, ind.Length - 1));
                stringus.AppendLine($"0001{Get_BIN(5)}{Get_BIN(7)}"); instr++;
                stringus.AppendLine($"0011{Get_BIN(0)}{Get_BIN(5)}"); instr++;
                // Set var 0 to Register 7
                stringus.AppendLine($"0001{Get_BIN(5)}{addr}"); instr++;
                stringus.AppendLine($"0011{Get_BIN(1)}{Get_BIN(5)}"); instr++;
                // Set var 1 to var adress
                stringus.AppendLine($"0010{Get_BIN(0)}{Get_BIN(1)}"); instr++;
                // Set REG 7 to var adress
            }
            else
            {
                stringus.AppendLine($"0001{Get_BIN(7)}{Get_BIN(int.Parse(ind))}"); instr++;
            }

            if (val[0] == '$')
            {
                string addr = Get_BIN_Varadress(val.Substring(1, val.Length - 1));
                stringus.AppendLine($"0001{Get_BIN(8)}{addr}"); instr++;
            }
            else
            {
                stringus.AppendLine($"0001{Get_BIN(5)}{Get_BIN(int.Parse(val))}");
                stringus.AppendLine($"0011{Get_BIN(3)}{Get_BIN(5)}"); instr++;
                stringus.AppendLine($"0001{Get_BIN(8)}{Get_BIN(3)}"); instr++;
            }
            stringus.Append("0101"); instr++;

            return stringus.ToString();
        }

        static string Get_BIN(int num)
        {
            string t = Convert.ToString(num, 2).PadLeft(32, '0');
            return t;
        }

        static string Get_BIN_Varadress(string varname)
        {
            string t = "";
            for (int i = VARS.Count - 1; i >= 0; i--)
            {
                if (VARS[i].name == varname)
                {
                    t = Get_BIN(i + 50); // first 50 vars are reserved
                }
            }

            return t;
        }


        static int Get_JUMP_NUM(string varname)
        {
            int t = -1;
            for (int i = JUMPS.Count - 1; i >= 0; i--)
            {
                if (JUMPS[i].name == varname)
                {
                    t = JUMPS[i].val;
                }
            }

            return t;
        }

    }
}
